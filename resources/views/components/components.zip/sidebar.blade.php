<!-- Sidebar -->
<div class="sidebar active" >
    <div class="list-group list-group-flush">
      <a href="{{route('storePanel')}}" class="list-group-item list-group-item-action "><i class="bi bi-house-fill"></i> <span>Dashboard</span> </a>
      <a href="{{route('products.pending')}}" class="list-group-item list-group-item-action "><i class="bi bi-box-seam-fill"></i> <span>Produits</span>  </a>
      <a href="{{route('orders')}}" class="list-group-item list-group-item-action "><i class="bi bi-cart-fill"></i> <span>Commandes</span>  </a>
      <a href="{{route('clients')}}" class="list-group-item list-group-item-action "> <i class="bi bi-people-fill"></i> <span>Clients</span>  </a>
      <a href="{{route('alerts')}}" class="list-group-item list-group-item-action "> <i class="bi bi-bell-fill"></i> <span>Alertes</span>  </a>
      <a href="{{route('settings')}}" class="list-group-item list-group-item-action "> <i class="bi bi-gear-fill"></i> <span>Paramètres</span>  </a>
    </div>
  </div>
  <!-- /#sidebar-wrapper -->
  